# Week 6 Assignment

### Requirements
Please take a look at reference.png and try to create something similar with the force-layouts
The color of the nodes is decided by `room_type` in the dataset.

> Note: Please start focussing on your final projects so we have the time in the semester to discuss the programming roadblocks. The assignments will be lighter going forward.