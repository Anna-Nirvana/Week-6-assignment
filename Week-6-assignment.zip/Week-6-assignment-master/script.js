const margin = {t: 50, r:50, b: 50, l: 50};
const size = {w: (0.8*innerWidth), h: (0.8*innerHeight)};//const size = {w: innerWidth, h: innerHeight};
const svg = d3.select('svg');

//setting up chart
svg.attr('width', size.w)
    .attr('height', size.h)
    .attr('class', 'chart');

const containerG = svg.append('g').classed('container', true);

//setting up legend
const legend = d3.select('#legend')

legend.attr('width', size.w)
        .attr('height', '400px')
        .attr('class', 'legend');

const containerL = legend.append('g').classed('container', true);

//importing data and plotting
d3.csv('data/airbnb.csv')
.then(function(data) {
    console.log(data);

    //define room type color scale (categorical)
    let typeColorScale = d3.scaleOrdinal(d3.schemeDark2);

    //and price buckets (band/linear?)
    // let scaleX = d3.scaleBand()
    //   .domain([0, 50, 100, 150, 200, 250, 300])

    let scaleX = d3.scaleLinear()
        .domain([0,800])
        .range([margin.l, size.w-margin.r]); //full horiz chart extent - not respecting margins???

    let centerForce = d3.forceCenter()
        .x(d => scaleX(d.room_type) )
        .y(size.h/2)
        .strength(20);

    let simulation = d3.forceSimulation(data)
        .force('collide', d3.forceCollide().strength(5)) 
        .force('charge', d3.forceManyBody().strength(-4))  // need charge for transition, otherwise they'll just glom to the center
        .force('x', d3.forceX().x(d => scaleX(+d.price))) //
        .force('y', d3.forceY().y(size.h/2));

    // // sort the nodes so the rarer ones are at the front???
    //   graph = graph.sort(function(a,b){ return b.size - a.size; });

    let node = containerG.append('g')
        .attr('stroke', '#fff')
        .attr('stroke-width', 1.5)
        .selectAll('circle')
        .data(data)
        .join('circle')
        .attr('yy', d => d.room_type)
        .attr('r', 7)  //d => d.price)
        .attr('fill', d => typeColorScale(d.room_type))
        .call(drag(simulation));

    simulation.on('tick', () => {
        node
            .attr('cx', d => d.x)
            .attr('cy', d => d.y);
        });

    //adding axis
    const xAxis = svg.append('g')
        .attr('class','axis')
        .attr('transform',`translate(0,${size.h-margin.b})`)
        .call(d3.axisBottom().scale(scaleX));
    
    const xAxisLabel = svg.append("text")
        .attr('class','axisLabel')
        .attr('x', size.w/2)
        .attr('y', size.h - 10)
        .attr("text-anchor","middle")
        .text("Price of Airb'n'b Rentals ($) by Type");

    //LEGEND

    // create a list of keys
    var keys = ["Entire Home/Apt", "Private Room", "Shared Room"]

    // Usually you have a color scale in your chart already
    var color = d3.scaleOrdinal()
        .domain(keys)
        .range(d3.schemeDark2);

    // Add one dot in the legend for each name.
    svg.selectAll("mydots")
        .data(keys)
        .enter()
        .append("circle")
            .attr("cx", (size.w-150))
            .attr("cy", function(d,i){ return 100 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
            .attr("r", 7)
            .style("fill", function(d){ return color(d)})

    // Add one name in the legend for each dot.
    svg.selectAll("mylabels")
        .data(keys)
        .enter()
        .append("text")
            .attr("x", (size.w-130))
            .attr("y", function(d,i){ return 100 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
            .style("fill", function(d){ return color(d)})
            .text(function(d){ return d})
            .attr("text-anchor", "left")
            .style("alignment-baseline", "middle")
            .attr("class", "legend")

});




function drag(simulation) {
  
    function dragstarted(event) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }
    
    function dragged(event) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }
    
    function dragended(event) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }
    
    return d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended);
  }
